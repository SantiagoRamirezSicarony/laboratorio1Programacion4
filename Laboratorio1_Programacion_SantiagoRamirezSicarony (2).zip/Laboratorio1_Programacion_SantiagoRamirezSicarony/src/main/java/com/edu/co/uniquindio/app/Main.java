package com.edu.co.uniquindio.app;

import com.edu.co.uniquindio.Modelo.Deporte;
import com.edu.co.uniquindio.Modelo.Enumeraciones.Especialidades;

public class Main {
    public static void main(String[] args) {
    }
}
