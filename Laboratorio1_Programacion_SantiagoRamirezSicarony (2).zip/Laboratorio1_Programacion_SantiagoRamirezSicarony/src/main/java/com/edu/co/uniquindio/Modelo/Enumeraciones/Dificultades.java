package com.edu.co.uniquindio.Modelo.Enumeraciones;

public enum Dificultades {
    BAJO,
    MEDIO,
    ALTO

}
