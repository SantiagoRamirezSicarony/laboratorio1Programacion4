package com.edu.co.uniquindio.Modelo.Enumeraciones;


public enum TiposDeMiembros {
    Juveniles,
    Adultos
}
