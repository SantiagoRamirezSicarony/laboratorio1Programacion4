package com.edu.co.uniquindio.Modelo.Enumeraciones;

import lombok.Getter;

import java.io.Serializable;

@Getter

public enum Especialidades implements Serializable {
    Natacion,
    Futbol,
    Voleibol,
    Baloncesto,
    Tenis,
    Badminton,
    Beisbol,
    Balonmano,
    Hockey,
    Rugby;






}
