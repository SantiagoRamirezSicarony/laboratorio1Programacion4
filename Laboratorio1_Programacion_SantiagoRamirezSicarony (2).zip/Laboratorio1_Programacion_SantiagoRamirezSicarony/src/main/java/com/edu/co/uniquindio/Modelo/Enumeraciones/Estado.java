package com.edu.co.uniquindio.Modelo.Enumeraciones;

public enum Estado {
    Programada,
    Completada

}
