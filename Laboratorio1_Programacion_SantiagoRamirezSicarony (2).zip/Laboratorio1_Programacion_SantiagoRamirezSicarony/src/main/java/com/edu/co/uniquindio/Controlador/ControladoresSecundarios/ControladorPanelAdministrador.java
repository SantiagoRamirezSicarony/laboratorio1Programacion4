package com.edu.co.uniquindio.Controlador.ControladoresSecundarios;

import com.edu.co.uniquindio.Controlador.ControladorPrincipal;
import com.edu.co.uniquindio.Modelo.Entrenador;
import com.edu.co.uniquindio.Modelo.Enumeraciones.Dificultades;
import com.edu.co.uniquindio.Modelo.Enumeraciones.Especialidades;
import com.edu.co.uniquindio.Modelo.Enumeraciones.Estado;
import com.edu.co.uniquindio.Modelo.Miembro;
import com.edu.co.uniquindio.Modelo.SesionesEntrenamiento;
import com.edu.co.uniquindio.Modelo.Solicitud;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class ControladorPanelAdministrador  implements Initializable {

    @FXML
    private ComboBox<Especialidades> cb_Especialidades;

    @FXML
    private AnchorPane crear_sesion;

    @FXML
    private TableColumn<SesionesEntrenamiento, String> ctv_descripcion_sesiones;

    @FXML
    private TableColumn<SesionesEntrenamiento, String> ctv_duracion_sesion;

    @FXML
    private TableColumn<SesionesEntrenamiento, String> ctv_entrenador_sesion;

    @FXML
    private TableColumn<Solicitud, String> ctv_especialidadSesion;

    @FXML
    private TableColumn<Entrenador, String> ctv_especialidad_entredor;

    @FXML
    private TableColumn<SesionesEntrenamiento, String> ctv_especialidad_sesion;

    @FXML
    private TableColumn<SesionesEntrenamiento, LocalDate> ctv_fecha_sesiones;

    @FXML
    private TableColumn<SesionesEntrenamiento, String> ctv_id;

    @FXML
    private TableColumn<Solicitud, String> ctv_nombreSeccion;

    @FXML
    private TableColumn<Entrenador, String> ctv_nombre_entrenador;

    @FXML
    private DatePicker dp_fecha;

    @FXML
    private TextArea tf_Descripcion;

    @FXML
    private TextArea tf_DescripcionSolicitud;

    @FXML
    private TextField tf_duracion;

    @FXML
    private TableView<Entrenador> tv_lista_entreadores;

    @FXML
    private TableView<SesionesEntrenamiento> tv_sesionesSolicitudes;

    @FXML
    private TableView<SesionesEntrenamiento> tv_sesiones_creadas;

    @FXML
    private TableView<Solicitud> tv_lista_solicitudes;

    @FXML
    private Label txt_duracion;

    @FXML
    private Label txt_entrenador;

    @FXML
    private Label txt_especialidad;

    @FXML
    private Label txt_fecha;
    @FXML
    private ComboBox<Dificultades> cB_DificultadSesiones;
    @FXML
    private Button bt_VerInformacion;

    ControladorPrincipal controladorPrincipal;


    @FXML
    void actualizar_sesiones(ActionEvent event) {


    }

    @FXML
    void asignar_sesion_miembro(ActionEvent event) {
        SesionesEntrenamiento sesion = tv_sesionesSolicitudes.getSelectionModel().getSelectedItem();
        Miembro miembro = tv_lista_solicitudes.getSelectionModel().getSelectedItem().getMiembro();
        miembro.getSesionesEntrenamientoEnUso().add(sesion);
    }

    @FXML
    void crear_sesion(ActionEvent event) throws Exception {

        controladorPrincipal.crearSesionesEntrenamiento(dp_fecha.getValue(),tf_duracion.getText(), Estado.Programada, tv_lista_entreadores.getSelectionModel().getSelectedItem()
                , controladorPrincipal.crearDeporte(cb_Especialidades.getSelectionModel().getSelectedItem(),cB_DificultadSesiones.getSelectionModel().getSelectedItem(),tf_Descripcion.getText()),tf_Descripcion.getText());
        actualizarTablas();

    }

    private void actualizarTablas() {
        llenarTvListaSesionesCreadas();
        llenarTvListaEntrenadores();
        llenarTvSesionesSolicitudes();
        llenarTvListaSolicitudes();
    }

    @FXML
    void eliminar_sesiones(ActionEvent event) {

        SesionesEntrenamiento sesionesEntrenamientos = tv_sesiones_creadas.getSelectionModel().getSelectedItem();
        controladorPrincipal.getSistemaDeportes().getListaSecionesEnElsistema().remove(sesionesEntrenamientos);
        actualizarTablas();
    }

    @FXML
    void limpiarCampos(ActionEvent event) {

        dp_fecha.setChronology(null);
        tf_Descripcion.setText("");
        tf_duracion.setText("");


    }

    /**
     * @param location  The location used to resolve relative paths for the root object, or
     *                  {@code null} if the location is not known.
     * @param resources The resources used to localize the root object, or {@code null} if
     *                  the root object was not localized.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        controladorPrincipal= ControladorPrincipal.getInstance();
        formatearColumnasTvListaSolicitudes();
        formatearColumnasTvListaEntranadores();
        formatearColumnasTvListaSesionesCreadas();
        formatearColumnasTvSesionesSolicitudes();
        llenarTvListaSolicitudes();
        llenarTvListaEntrenadores();
        llenarTvListaSesionesCreadas();
        llenarTvSesionesSolicitudes();
        llenarCombox();
        llenarComboxDificultad();


    }

    private void llenarComboxDificultad() {
        cB_DificultadSesiones.getItems().clear();
        cB_DificultadSesiones.getItems().addAll(Dificultades.values());
    }

    private void llenarCombox() {
        cb_Especialidades.getItems().clear();
        cb_Especialidades.getItems().addAll(Especialidades.values());
    }

    private void llenarTvSesionesSolicitudes() {
        tv_sesionesSolicitudes.getItems().addAll(controladorPrincipal.getSistemaDeportes().getListaSecionesEnElsistema());
    }

    private void llenarTvListaSesionesCreadas() {
        tv_sesiones_creadas.getItems().clear();
        tv_sesiones_creadas.getItems().addAll(controladorPrincipal.getSistemaDeportes().getListaSecionesEnElsistema());
    }

    private void llenarTvListaEntrenadores() {
        tv_lista_entreadores.getItems().clear();
        tv_lista_entreadores.getItems().addAll(controladorPrincipal.getSistemaDeportes().getListaEntrenadores());
    }

    private void llenarTvListaSolicitudes() {
        tv_lista_solicitudes.getItems().addAll(controladorPrincipal.getSistemaDeportes().getListaSolicitudesMiembros());
    }

    private void formatearColumnasTvSesionesSolicitudes() {
        ctv_id.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getID()));

    }

    private void formatearColumnasTvListaSesionesCreadas() {
        ctv_fecha_sesiones.setCellValueFactory(new PropertyValueFactory<>("fecha"));
        ctv_descripcion_sesiones.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
        ctv_duracion_sesion.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getDuracion()));
        ctv_especialidad_sesion.setCellValueFactory(cellData->new SimpleStringProperty(String.valueOf(cellData.getValue().getEntrenadorSesion().getEspecialidad_Entrenador())));
        ctv_entrenador_sesion.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getEntrenadorSesion().getNombre()));
    }

    private void formatearColumnasTvListaEntranadores() {
        ctv_nombre_entrenador.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getNombre()));
        ctv_especialidad_entredor.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getEspecialidad_Entrenador().toString()));
    }

    private void formatearColumnasTvListaSolicitudes() {
        ctv_nombreSeccion.setCellValueFactory(cellData->new SimpleStringProperty(cellData.getValue().getMiembro().getNombre()));
        ctv_especialidadSesion.setCellValueFactory(cellData->new SimpleStringProperty(String.valueOf(cellData.getValue().getEspecialidades())));
    }

    public void verInformacion(ActionEvent actionEvent) {
        SesionesEntrenamiento sesion = tv_sesiones_creadas.getSelectionModel().getSelectedItem();

        dp_fecha.setChronology(sesion.getFecha().getChronology());
        tf_Descripcion.setText(sesion.getDescripcion());
        tf_duracion.setText(sesion.getDuracion());


    }

    public void volver_menu(ActionEvent actionEvent) {
        controladorPrincipal.navegar("Login.fxml","menu");
        controladorPrincipal.cerrarVentana(txt_entrenador);
    }
}

